<?php
declare(strict_types=1);

session_start();

require_once __DIR__ . '/db.php';

if ($_SERVER['REQUEST_METHOD'] !== 'POST') {
    http_response_code(405);
    exit('Method not allowed.');
}

$bookingId = filter_input(INPUT_POST, 'booking_id', FILTER_VALIDATE_INT);
$status = $_POST['booking_status'] ?? '';

$allowedStatuses = [
    'Pending',
    'Ongoing',
    'Completed'
];

if (!$bookingId || !in_array($status, $allowedStatuses, true)) {
    http_response_code(400);
    exit('Invalid booking ID or status.');
}

try {
    $stmt = $pdo->prepare("
        UPDATE bookings
        SET booking_status = :status
        WHERE booking_id = :booking_id
    ");

    $stmt->execute([
        ':status' => $status,
        ':booking_id' => $bookingId
    ]);

    header('Location: admin.php?updated=1');
    exit;

} catch (PDOException $e) {
    error_log($e->getMessage());
    http_response_code(500);
    exit('Unable to update booking status.');
}