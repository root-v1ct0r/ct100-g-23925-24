<?php
declare(strict_types=1);

require_once __DIR__ . '/db.php';

$stmt = $pdo->query("
    SELECT
        b.*,
        GROUP_CONCAT(
            s.service_name
            ORDER BY s.service_name
            SEPARATOR ', '
        ) AS selected_services
    FROM bookings b
    LEFT JOIN booking_services bs
        ON b.booking_id = bs.booking_id
    LEFT JOIN services s
        ON bs.service_id = s.service_id
    GROUP BY b.booking_id
    ORDER BY b.created_at DESC
");

$bookings = $stmt->fetchAll();

$totalBookings = count($bookings);
$totalRevenue = 0;

foreach ($bookings as $booking) {
    $totalRevenue += (float) $booking['estimated_cost'];
}

function e(string $value): string
{
    return htmlspecialchars(
        $value,
        ENT_QUOTES | ENT_SUBSTITUTE,
        'UTF-8'
    );
}
?>
<!DOCTYPE html>
<html lang="en">
<head>
    <meta charset="UTF-8">
    <meta name="viewport" content="width=device-width, initial-scale=1.0">

    <title>Admin Dashboard | AutoCare Garage</title>

    <style>
        * {
            box-sizing: border-box;
        }

        body {
            margin: 0;
            padding: 24px;
            background: #f3f6fb;
            color: #1f2937;
            font-family: Arial, sans-serif;
        }

        .container {
            max-width: 1400px;
            margin: auto;
        }

        h1 {
            color: #12304a;
        }

        .summary {
            display: flex;
            flex-wrap: wrap;
            gap: 20px;
            margin: 25px 0;
        }

        .card {
            flex: 1;
            min-width: 200px;
            padding: 24px;
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.06);
        }

        .card h3 {
            margin-top: 0;
            color: #64748b;
            font-size: 14px;
        }

        .card p {
            margin-bottom: 0;
            font-size: 26px;
            font-weight: bold;
        }

        .table-wrap {
            overflow-x: auto;
            background: white;
            border-radius: 12px;
            box-shadow: 0 3px 12px rgba(0, 0, 0, 0.06);
        }

        table {
            width: 100%;
            border-collapse: collapse;
            min-width: 1150px;
        }

        th, td {
            padding: 14px;
            border-bottom: 1px solid #e5e7eb;
            text-align: left;
            vertical-align: top;
        }

        th {
            background: #12304a;
            color: white;
        }

        tr:hover td {
            background: #f8fafc;
        }

        .status {
            display: inline-block;
            padding: 6px 10px;
            background: #fef3c7;
            color: #92400e;
            border-radius: 20px;
            font-size: 12px;
        }

        .empty {
            padding: 30px;
            text-align: center;
        }

        .back {
            display: inline-block;
            margin-bottom: 15px;
            color: #075985;
            text-decoration: none;
        }

        @media (max-width: 600px) {
            body {
                padding: 12px;
            }
        }

```css
select,
button {
    padding: 9px;
    border-radius: 6px;
    font-size: 13px;
}

select {
    border: 1px solid #cbd5e1;
    background: white;
    margin-bottom: 6px;
    width: 180px;
}

button {
    border: none;
    background: #12304a;
    color: white;
    cursor: pointer;
}

button:hover {
    background: #1d4ed8;
}

.status-pending {
    background: #fef3c7;
    color: #92400e;
}

.status-ongoing {
    background: #dbeafe;
    color: #1d4ed8;
}

.status-completed {
    background: #dcfce7;
    color: #166534;
}
```


    </style>
</head>

<body>
<div class="container">

    <a class="back" href="index.html">&larr; Return to website</a>

    <h1>AutoCare Garage Admin Dashboard</h1>

    <p>View customer bookings and their selected services.</p>

    <div class="summary">
        <div class="card">
            <h3>Total Bookings</h3>
            <p><?= $totalBookings ?></p>
        </div>

        <div class="card">
            <h3>Total Estimated Value</h3>
            <p>KSh <?= number_format($totalRevenue, 2) ?></p>
        </div>
    </div>

    <div class="table-wrap">
        <?php if (empty($bookings)): ?>

            <div class="empty">
                No customer bookings have been submitted yet.
            </div>

        <?php else: ?>

            <table>
                <thead>
                    <tr>
                        <th>ID</th>
                        <th>Customer</th>
                        <th>Phone</th>
                        <th>Email</th>
                        <th>Vehicle</th>
                        <th>Registration</th>
                        <th>Service Date</th>
                        <th>Selected Services</th>
                        <th>Estimated Cost</th>
                        <th>Booking Status</th>
                        <th>Update Status</th>
                        <th>Submitted</th>
                    </tr>
                </thead>

                <tbody>
                <?php foreach ($bookings as $booking): ?>
                    <tr>
                        <td><?= (int) $booking['booking_id'] ?></td>

                        <td><?= e($booking['customer_name']) ?></td>

                        <td><?= e($booking['phone']) ?></td>

                        <td><?= e($booking['email']) ?></td>

                        <td>
                            <?= e($booking['vehicle_type']) ?><br>
                            <?= e($booking['vehicle_model']) ?><br>
                            Year: <?= e((string) $booking['manufacture_year']) ?>
                        </td>

                        <td><?= e($booking['registration_number']) ?></td>

                        <td><?= e($booking['preferred_date']) ?></td>

                        <td>
                            <?= e($booking['selected_services'] ?? 'No services recorded') ?>
                        </td>

                        <td>
                            KSh <?= number_format((float) $booking['estimated_cost'], 2) ?>
                        </td>

                        ```php
<td>
    <?php
    $currentStatus = $booking['booking_status'] ?? 'Pending';

    $statusClass = strtolower($currentStatus);
    ?>

    <span class="status status-<?= e($statusClass) ?>">
        <?= e($currentStatus) ?>
    </span>
</td>

<td>
    <form action="update_status.php" method="POST">

        <input
            type="hidden"
            name="booking_id"
            value="<?= (int) $booking['booking_id'] ?>"
        >

        <select name="booking_status" required>
            <option value="Pending"
                <?= $currentStatus === 'Pending' ? 'selected' : '' ?>>
                Pending
            </option>

            <option value="Ongoing"
                <?= $currentStatus === 'Ongoing' ? 'selected' : '' ?>>
                Ongoing / Working On
            </option>

            <option value="Completed"
                <?= $currentStatus === 'Completed' ? 'selected' : '' ?>>
                Completed / Finished
            </option>
        </select>

        <button type="submit">Save Status</button>

    </form>
</td>

<td><?= e($booking['created_at']) ?></td>
```


                    </tr>
                <?php endforeach; ?>
                </tbody>
            </table>

        <?php endif; ?>
    </div>

</div>
</body>
</html>